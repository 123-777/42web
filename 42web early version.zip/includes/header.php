<?php
// valores padrão (caso a página não defina nada)
$page_title = $page_title ?? "42web";
$page_desc  = $page_desc  ?? "Community forums, news and discussions";
$page_image = $page_image ?? "https://we-are.42web.io/assets/embed.png";
$page_url   = $page_url   ?? "https://we-are.42web.io/";
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title><?= htmlspecialchars($page_title) ?></title>

<!-- OPEN GRAPH / DISCORD -->
<meta property="og:type" content="website">
<meta property="og:title" content="<?= htmlspecialchars($page_title) ?>">
<meta property="og:description" content="<?= htmlspecialchars($page_desc) ?>">
<meta property="og:image" content="<?= $page_image ?>">
<meta property="og:url" content="<?= $page_url ?>">
<meta name="theme-color" content="#1f2937">

<!-- TWITTER (opcional, mas bom) -->
<meta name="twitter:card" content="summary_large_image">

<!-- RESPONSIVE -->
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- CSS -->
<link rel="stylesheet" href="/style.css">
</head>

<body>

<!-- TOPBAR -->
<div class="topbar">
  <a href="/"><span>Home</span></a>
  <a href="/forum.php"><span>Forums</span></a>
  <a href="/users.php"><span>Users</span></a>
  <a href="/news.php"><span>News</span></a>
  <a href="https://discord.gg/FHSs9kpsSZ" target="_blank"><span>Discord</span></a>
</div>
