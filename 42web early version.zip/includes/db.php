<?php
$conn = mysqli_connect(
  "sql211.infinityfree.com",
  "if0_41057633",
  "RfciNQNqLk",
  "if0_41057633_42web"
);

if (!$conn) {
  die("Database Error");
}
