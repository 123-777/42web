<?php
session_start();

function logged() {
  return isset($_SESSION['user_id']);
}
