<?php
include "../includes/db.php";
include "../includes/auth.php";

$id = intval($_GET['id']);
mysqli_query($conn, "UPDATE uploads SET approved=1 WHERE id=$id");

header("Location: uploads.php");
