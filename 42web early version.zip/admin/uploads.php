<?php
include "../includes/db.php";
include "../includes/auth.php";
if ($_SESSION['is_admin'] != 1) die("sem permissão");

$uploads = mysqli_query($conn,
  "SELECT uploads.*, users.username
   FROM uploads
   JOIN users ON users.id = uploads.user_id
   WHERE approved=0"
);
?>

<h2>Imagens pendentes</h2>

<?php while ($u = mysqli_fetch_assoc($uploads)): ?>
  <div class="box">
    <b><?= $u['username'] ?></b><br>
    <img src="../<?= $u['file'] ?>" width="200"><br><br>

    <a href="approve_upload.php?id=<?= $u['id'] ?>">✅</a>
    <a href="reject_upload.php?id=<?= $u['id'] ?>">❌</a>
  </div>
<?php endwhile; ?>
