<?php
$id = intval($_GET['id']);
mysqli_query($conn, "
  UPDATE users
  SET avatar=pending_avatar,
      pending_avatar=NULL,
      avatar_approved=1
  WHERE id=$id
");
