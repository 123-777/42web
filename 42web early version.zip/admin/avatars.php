<?php
$users = mysqli_query($conn,
  "SELECT * FROM users WHERE avatar_approved=0"
);
?>

<h2>Pending Avatars</h2>

<?php while ($u = mysqli_fetch_assoc($users)): ?>
  <div class="box">
    <b><?= $u['username'] ?></b><br>
    <img src="../<?= $u['pending_avatar'] ?>" width="100"><br><br>

    <a href="approve_avatar.php?id=<?= $u['id'] ?>">✅ Approve</a>
    <a href="reject_avatar.php?id=<?= $u['id'] ?>">❌ Reject</a>
  </div>
<?php endwhile; ?>
