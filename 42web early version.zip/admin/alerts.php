<?php
include "../includes/db.php";
include "../includes/auth.php";

if ($_SESSION['is_admin'] != 1) die("get out.");

if ($_POST) {
  $msg = $_POST['message'];
  mysqli_query($conn, "INSERT INTO alerts (message) VALUES ('$msg')");
}
?>

<form method="post" class="box">
  <textarea name="message" placeholder="test"></textarea>
  <button>Enviar alerta</button>
</form>
